/**
 * Assembles classes only related to the {@link org.apache.http.client.HttpClient} implementation.
 */
package com.googlecode.sardine.impl;
